# QrCodeApi
单文件实现的PHP二维码API
